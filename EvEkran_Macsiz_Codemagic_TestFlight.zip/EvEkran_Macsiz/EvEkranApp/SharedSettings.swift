import Foundation
import Combine

final class SharedSettings: ObservableObject {
    private let defaults = UserDefaults(suiteName: AppConstants.appGroup)!

    @Published var serverURL: String {
        didSet { defaults.set(serverURL, forKey: "serverURL") }
    }

    @Published var room: String {
        didSet { defaults.set(room, forKey: "room") }
    }

    @Published var token: String {
        didSet { defaults.set(token, forKey: "token") }
    }

    init() {
        self.serverURL = defaults.string(forKey: "serverURL") ?? "wss://SUNUCU-ADRESIN/ws"
        self.room = defaults.string(forKey: "room") ?? "EV-001"
        self.token = defaults.string(forKey: "token") ?? UUID().uuidString.replacingOccurrences(of: "-", with: "")
    }
}
