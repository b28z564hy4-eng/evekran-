import SwiftUI

struct HomeDeviceView: View {
    @ObservedObject var settings: SharedSettings

    var body: some View {
        Form {
            Section("Bağlantı") {
                TextField("Sunucu", text: $settings.serverURL)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                TextField("Oda kodu", text: $settings.room)
                    .textInputAutocapitalization(.characters)
                    .autocorrectionDisabled()
                SecureField("Güvenlik anahtarı", text: $settings.token)
            }

            Section("Ekran yayını") {
                HStack {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("Yayını Başlat / Durdur")
                            .font(.headline)
                        Text("Apple'ın sistem ekranı açılır. Mikrofon kapalıdır.")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    Spacer()
                    BroadcastPicker()
                        .frame(width: 52, height: 52)
                }
            }

            Section("Önemli") {
                Label("Ses paketleri gönderilmez.", systemImage: "mic.slash.fill")
                Label("Kamera kullanılmaz.", systemImage: "camera.fill")
                Text("iOS, ekran paylaşımının kullanıcı tarafından başlatılmasını zorunlu tutar. Yayın başladıktan sonra telefon başka uygulamalara geçse de ekran akışı devam edebilir.")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
            }
        }
        .navigationTitle("Ev Telefonu")
    }
}
