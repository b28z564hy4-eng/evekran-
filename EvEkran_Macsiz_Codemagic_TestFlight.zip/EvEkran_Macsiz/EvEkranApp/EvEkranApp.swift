import SwiftUI

@main
struct EvEkranApp: App {
    var body: some Scene {
        WindowGroup {
            RootView()
        }
    }
}
