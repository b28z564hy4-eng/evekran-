import SwiftUI

struct RootView: View {
    @StateObject private var settings = SharedSettings()

    var body: some View {
        NavigationStack {
            VStack(spacing: 22) {
                Image(systemName: "iphone.gen3.radiowaves.left.and.right")
                    .font(.system(size: 64))

                Text("Ev Ekranı")
                    .font(.largeTitle.bold())

                Text("Kamera ve mikrofon olmadan, kendi iPhone'unun ekranını diğer iPhone'dan görüntülemek için prototip.")
                    .multilineTextAlignment(.center)
                    .foregroundStyle(.secondary)

                NavigationLink {
                    HomeDeviceView(settings: settings)
                } label: {
                    Label("Bu telefon evde kalacak", systemImage: "house.fill")
                        .frame(maxWidth: .infinity)
                        .padding()
                }
                .buttonStyle(.borderedProminent)

                NavigationLink {
                    ControllerView(settings: settings)
                } label: {
                    Label("Bu telefon kontrol telefonu", systemImage: "iphone.gen2")
                        .frame(maxWidth: .infinity)
                        .padding()
                }
                .buttonStyle(.bordered)
            }
            .padding()
        }
    }
}
