import SwiftUI

struct ControllerView: View {
    @ObservedObject var settings: SharedSettings
    @StateObject private var viewer = ViewerConnection()

    var body: some View {
        VStack(spacing: 14) {
            GroupBox("Bağlantı ayarları") {
                VStack(spacing: 10) {
                    TextField("Sunucu", text: $settings.serverURL)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .textFieldStyle(.roundedBorder)

                    TextField("Oda kodu", text: $settings.room)
                        .textInputAutocapitalization(.characters)
                        .autocorrectionDisabled()
                        .textFieldStyle(.roundedBorder)

                    SecureField("Güvenlik anahtarı", text: $settings.token)
                        .textFieldStyle(.roundedBorder)
                }
            }

            HStack {
                Circle()
                    .frame(width: 10, height: 10)
                    .foregroundStyle(viewer.isConnected ? .green : .gray)
                Text(viewer.status)
                    .font(.subheadline)
                Spacer()
                Text("\(viewer.framesReceived) kare")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            ZStack {
                RoundedRectangle(cornerRadius: 18)
                    .fill(.black)
                    .aspectRatio(9.0 / 19.5, contentMode: .fit)

                if let image = viewer.image {
                    Image(uiImage: image)
                        .resizable()
                        .scaledToFit()
                        .clipShape(RoundedRectangle(cornerRadius: 18))
                } else {
                    VStack(spacing: 8) {
                        Image(systemName: "iphone.gen3")
                            .font(.system(size: 42))
                            .foregroundStyle(.white.opacity(0.7))
                        Text("Ekran bekleniyor")
                            .foregroundStyle(.white.opacity(0.8))
                    }
                }
            }
            .frame(maxHeight: .infinity)

            Button {
                if viewer.isConnected {
                    viewer.disconnect()
                } else {
                    viewer.connect(
                        serverURL: settings.serverURL,
                        room: settings.room,
                        token: settings.token
                    )
                }
            } label: {
                Label(
                    viewer.isConnected ? "Bağlantıyı Kes" : "Ekranı İzle",
                    systemImage: viewer.isConnected ? "xmark.circle" : "eye.fill"
                )
                .frame(maxWidth: .infinity)
                .padding(.vertical, 10)
            }
            .buttonStyle(.borderedProminent)
        }
        .padding()
        .navigationTitle("Kontrol Telefonu")
        .onDisappear { viewer.disconnect() }
    }
}
