import Foundation

enum AppConstants {
    static let appGroup = "__APP_GROUP_ID__"

    static let broadcastExtensionBundleID: String = {
        let base = Bundle.main.bundleIdentifier ?? "__APP_BUNDLE_ID__"
        return base + ".Broadcast"
    }()
}
