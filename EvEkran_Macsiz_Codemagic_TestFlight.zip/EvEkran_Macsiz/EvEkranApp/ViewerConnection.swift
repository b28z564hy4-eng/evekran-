import Foundation
import UIKit
import Combine

final class ViewerConnection: NSObject, ObservableObject {
    @Published var image: UIImage?
    @Published var status = "Bağlı değil"
    @Published var isConnected = false
    @Published var framesReceived = 0

    private var session: URLSession?
    private var task: URLSessionWebSocketTask?

    func connect(serverURL: String, room: String, token: String) {
        disconnect()

        guard var components = URLComponents(string: serverURL) else {
            status = "Sunucu adresi geçersiz"
            return
        }

        var items = components.queryItems ?? []
        items.append(URLQueryItem(name: "role", value: "viewer"))
        items.append(URLQueryItem(name: "room", value: room))
        items.append(URLQueryItem(name: "token", value: token))
        components.queryItems = items

        guard let url = components.url else {
            status = "Bağlantı adresi oluşturulamadı"
            return
        }

        let configuration = URLSessionConfiguration.default
        configuration.timeoutIntervalForRequest = 15
        let session = URLSession(configuration: configuration)
        self.session = session

        let task = session.webSocketTask(with: url)
        self.task = task
        task.resume()

        DispatchQueue.main.async {
            self.status = "Bağlanıyor…"
            self.isConnected = true
        }

        receiveLoop()
    }

    func disconnect() {
        task?.cancel(with: .goingAway, reason: nil)
        task = nil
        session?.invalidateAndCancel()
        session = nil
        DispatchQueue.main.async {
            self.isConnected = false
            self.status = "Bağlı değil"
        }
    }

    private func receiveLoop() {
        task?.receive { [weak self] result in
            guard let self else { return }

            switch result {
            case .failure(let error):
                DispatchQueue.main.async {
                    self.status = "Bağlantı kesildi: \(error.localizedDescription)"
                    self.isConnected = false
                }

            case .success(let message):
                switch message {
                case .data(let data):
                    if let image = UIImage(data: data) {
                        DispatchQueue.main.async {
                            self.image = image
                            self.framesReceived += 1
                            self.status = "Canlı"
                            self.isConnected = true
                        }
                    }

                case .string(let text):
                    DispatchQueue.main.async {
                        if text.contains("home-online") {
                            self.status = "Ev telefonu çevrimiçi"
                        } else if text.contains("home-offline") {
                            self.status = "Ev telefonu çevrimdışı"
                        } else {
                            self.status = text
                        }
                    }

                @unknown default:
                    break
                }

                self.receiveLoop()
            }
        }
    }
}
