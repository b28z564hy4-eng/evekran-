import http from "http";
import { WebSocketServer, WebSocket } from "ws";

const PORT = Number(process.env.PORT || 8080);
const rooms = new Map();

function getRoom(name) {
  if (!rooms.has(name)) {
    rooms.set(name, { home: null, viewers: new Set(), token: null });
  }
  return rooms.get(name);
}

function sendJSON(ws, value) {
  if (ws?.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify(value));
  }
}

const server = http.createServer((req, res) => {
  if (req.url === "/health") {
    res.writeHead(200, { "content-type": "application/json" });
    res.end(JSON.stringify({ ok: true }));
    return;
  }
  res.writeHead(404);
  res.end();
});

const wss = new WebSocketServer({ server, path: "/ws", maxPayload: 2 * 1024 * 1024 });

wss.on("connection", (ws, request) => {
  const base = `http://${request.headers.host}`;
  const url = new URL(request.url, base);

  const role = url.searchParams.get("role");
  const roomName = (url.searchParams.get("room") || "").trim();
  const token = (url.searchParams.get("token") || "").trim();

  if (!["home", "viewer"].includes(role) || !roomName || token.length < 12) {
    ws.close(1008, "invalid-auth");
    return;
  }

  const room = getRoom(roomName);

  if (room.token && room.token !== token) {
    ws.close(1008, "unauthorized");
    return;
  }

  room.token = token;

  if (role === "home") {
    if (room.home && room.home !== ws) {
      try { room.home.close(1012, "replaced"); } catch {}
    }
    room.home = ws;
    for (const viewer of room.viewers) {
      sendJSON(viewer, { type: "status", state: "home-online" });
    }
  } else {
    room.viewers.add(ws);
    sendJSON(ws, {
      type: "status",
      state: room.home?.readyState === WebSocket.OPEN ? "home-online" : "home-offline"
    });
  }

  ws.on("message", (data, isBinary) => {
    if (role !== "home") return;

    if (isBinary) {
      for (const viewer of room.viewers) {
        if (viewer.readyState === WebSocket.OPEN && viewer.bufferedAmount < 1_500_000) {
          viewer.send(data, { binary: true });
        }
      }
      return;
    }

    const text = data.toString();
    for (const viewer of room.viewers) {
      if (viewer.readyState === WebSocket.OPEN) {
        viewer.send(text);
      }
    }
  });

  ws.on("close", () => {
    if (role === "home" && room.home === ws) {
      room.home = null;
      for (const viewer of room.viewers) {
        sendJSON(viewer, { type: "status", state: "home-offline" });
      }
    } else if (role === "viewer") {
      room.viewers.delete(ws);
    }

    if (!room.home && room.viewers.size === 0) {
      rooms.delete(roomName);
    }
  });
});


const heartbeatInterval = setInterval(() => {
  for (const ws of wss.clients) {
    if (ws.readyState === WebSocket.OPEN) {
      try { ws.ping(); } catch {}
    }
  }
}, 25000);

wss.on("close", () => clearInterval(heartbeatInterval));

server.listen(PORT, "0.0.0.0", () => {
  console.log(`EvEkran relay listening on :${PORT}`);
});
