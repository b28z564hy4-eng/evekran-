#!/bin/bash
set -euo pipefail

: "${APP_BUNDLE_ID:?APP_BUNDLE_ID tanımlı değil}"
: "${APP_GROUP_ID:?APP_GROUP_ID tanımlı değil}"

if [[ "$APP_BUNDLE_ID" == *"REPLACE"* || "$APP_GROUP_ID" == *"REPLACE"* ]]; then
  echo "APP_BUNDLE_ID / APP_GROUP_ID örnek değer olarak kalmış."
  exit 2
fi

echo "Bundle ID: $APP_BUNDLE_ID"
echo "App Group: $APP_GROUP_ID"

python3 - <<'PY'
from pathlib import Path
import os

bundle = os.environ["APP_BUNDLE_ID"]
group = os.environ["APP_GROUP_ID"]

for p in Path(".").rglob("*"):
    if not p.is_file():
        continue
    if any(part in {".git", "node_modules"} for part in p.parts):
        continue
    if p.suffix not in {".swift", ".entitlements", ".yml", ".yaml", ".plist"}:
        continue
    try:
        text = p.read_text(encoding="utf-8")
    except Exception:
        continue
    text = text.replace("__APP_BUNDLE_ID__", bundle)
    text = text.replace("__APP_GROUP_ID__", group)
    p.write_text(text, encoding="utf-8")
PY

echo "Bulut yapılandırması uygulandı."
