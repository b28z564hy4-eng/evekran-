import ReplayKit

final class SampleHandler: RPBroadcastSampleHandler {
    private let sender = BroadcastSender()

    override func broadcastStarted(withSetupInfo setupInfo: [String : NSObject]?) {
        sender.connect()
    }

    override func broadcastPaused() {}

    override func broadcastResumed() {}

    override func broadcastFinished() {
        sender.disconnect()
    }

    override func processSampleBuffer(_ sampleBuffer: CMSampleBuffer,
                                      with sampleBufferType: RPSampleBufferType) {
        switch sampleBufferType {
        case .video:
            sender.sendVideo(sampleBuffer: sampleBuffer)

        case .audioApp, .audioMic:
            // Bilerek hiçbir ses verisi işlenmiyor veya gönderilmiyor.
            break

        @unknown default:
            break
        }
    }
}
