import Foundation
import ReplayKit
import CoreImage
import UIKit
import VideoToolbox

final class BroadcastSender {
    private var session: URLSession?
    private var task: URLSessionWebSocketTask?
    private let ciContext = CIContext(options: [.cacheIntermediates: false])

    private var lastFrameTime: CFTimeInterval = 0
    private let minimumFrameInterval: CFTimeInterval = 0.25 // yaklaşık 4 FPS

    private let lock = NSLock()
    private var sendInFlight = false

    func connect() {
        guard var components = URLComponents(string: BroadcastConfig.serverURL) else { return }

        var items = components.queryItems ?? []
        items.append(URLQueryItem(name: "role", value: "home"))
        items.append(URLQueryItem(name: "room", value: BroadcastConfig.room))
        items.append(URLQueryItem(name: "token", value: BroadcastConfig.token))
        components.queryItems = items

        guard let url = components.url else { return }

        let configuration = URLSessionConfiguration.ephemeral
        configuration.timeoutIntervalForRequest = 15

        let session = URLSession(configuration: configuration)
        self.session = session

        let task = session.webSocketTask(with: url)
        self.task = task
        task.resume()

        task.send(.string(#"{"type":"status","state":"broadcasting"}"#)) { _ in }
    }

    func disconnect() {
        task?.send(.string(#"{"type":"status","state":"stopped"}"#)) { _ in }
        task?.cancel(with: .normalClosure, reason: nil)
        task = nil
        session?.invalidateAndCancel()
        session = nil
    }

    func sendVideo(sampleBuffer: CMSampleBuffer) {
        let now = CACurrentMediaTime()
        guard now - lastFrameTime >= minimumFrameInterval else { return }
        lastFrameTime = now

        lock.lock()
        if sendInFlight {
            lock.unlock()
            return
        }
        sendInFlight = true
        lock.unlock()

        guard
            let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer),
            let jpeg = makeJPEG(pixelBuffer: pixelBuffer)
        else {
            finishSend()
            return
        }

        task?.send(.data(jpeg)) { [weak self] _ in
            self?.finishSend()
        }
    }

    private func finishSend() {
        lock.lock()
        sendInFlight = false
        lock.unlock()
    }

    private func makeJPEG(pixelBuffer: CVPixelBuffer) -> Data? {
        autoreleasepool {
            let source = CIImage(cvPixelBuffer: pixelBuffer)
            let extent = source.extent

            let maxWidth: CGFloat = 720
            let scale = min(1.0, maxWidth / extent.width)
            let transformed = source.transformed(by: CGAffineTransform(scaleX: scale, y: scale))

            guard let cgImage = ciContext.createCGImage(transformed, from: transformed.extent) else {
                return nil
            }

            let image = UIImage(cgImage: cgImage)
            return image.jpegData(compressionQuality: 0.45)
        }
    }
}
