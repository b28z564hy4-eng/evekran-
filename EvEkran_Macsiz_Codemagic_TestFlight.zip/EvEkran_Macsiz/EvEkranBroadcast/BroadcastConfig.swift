import Foundation

enum BroadcastConfig {
    static let appGroup = "__APP_GROUP_ID__"

    static var defaults: UserDefaults {
        UserDefaults(suiteName: appGroup)!
    }

    static var serverURL: String {
        defaults.string(forKey: "serverURL") ?? ""
    }

    static var room: String {
        defaults.string(forKey: "room") ?? ""
    }

    static var token: String {
        defaults.string(forKey: "token") ?? ""
    }
}
