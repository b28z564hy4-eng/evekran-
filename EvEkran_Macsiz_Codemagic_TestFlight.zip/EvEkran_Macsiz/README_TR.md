# Ev Ekranı – iPhone ekran izleme prototipi

Bu proje iki **sana ait iPhone** arasında, kamera ve mikrofon kullanmadan ekran görüntüsü aktarımı için hazırlanmıştır.

## Ne yapıyor?

- Evdeki iPhone: iOS ekran paylaşımını Apple'ın sistem arayüzü üzerinden başlatır.
- Broadcast Upload Extension: yalnızca **video ekran karelerini** alır.
- Ses türleri (`audioApp`, `audioMic`) kodda bilerek yok sayılır.
- Kareler JPEG'e küçültülür ve WebSocket ile relay sunucusuna gönderilir.
- Kontrol iPhone'u aynı oda kodu + güvenlik anahtarıyla bağlanır ve kareleri gösterir.

## Önemli iOS kısıtı

iOS 26'da tam ekran yayını kullanıcı etkileşimi olmadan uzaktan başlatılamaz.
Evden çıkmadan önce ev telefonunda Apple'ın yayın düğmesine basıp ekran paylaşımını başlatmalısın.
Bu proje bu korumayı atlatmaya çalışmaz.

## Gerekenler

1. macOS + Xcode
2. İki iPhone
3. Apple Developer imzalama kimliği
4. İnternetten erişilebilen bir WebSocket sunucusu (`wss://.../ws`)
5. İstersen proje üretmek için XcodeGen

## 1. Bundle ID'leri değiştir

Aşağıdaki örnek kimlikleri kendi benzersiz kimliklerinle değiştir:

- `com.example.EvEkran`
- `com.example.EvEkran.Broadcast`
- `group.com.example.EvEkran`

Değiştirmen gereken yerler:

- `project.yml`
- `EvEkranApp/AppConstants.swift`
- `EvEkranApp/EvEkran.entitlements`
- `EvEkranBroadcast/BroadcastConfig.swift`
- `EvEkranBroadcast/EvEkranBroadcast.entitlements`

## 2. Xcode projesini oluştur

XcodeGen kuruluysa proje klasöründe:

```bash
xcodegen generate
open EvEkran.xcodeproj
```

XcodeGen kullanmak istemezsen Xcode'da yeni iOS App + Broadcast Upload Extension hedefi oluşturup Swift dosyalarını ilgili hedeflere ekleyebilirsin.

## 3. Signing & Capabilities

Hem ana uygulama hem Broadcast Extension için:

- Aynı Apple Developer Team'i seç.
- `App Groups` capability ekle.
- Aynı App Group'u işaretle: `group....EvEkran`

## 4. Relay sunucusu

Sunucuda:

```bash
cd RelayServer
npm install
npm start
```

Varsayılan port: `8080`

Sağlık kontrolü:

```text
http://SUNUCU:8080/health
```

Üretimde TLS reverse proxy kullan ve uygulamaya:

```text
wss://alanadiniz.com/ws
```

yaz.

## 5. Ev telefonunda

1. Uygulamayı aç.
2. "Bu telefon evde kalacak" seç.
3. Sunucu adresini yaz.
4. Oda kodu belirle.
5. Güvenlik anahtarını belirle.
6. Yayın düğmesine bas.
7. Apple yayın panelinden `Ev Ekranı Yayını` seç ve yayını başlat.
8. Mikrofon kapalı kalır.

## 6. Kontrol telefonunda

1. Aynı uygulamayı aç.
2. "Bu telefon kontrol telefonu" seç.
3. Aynı sunucu + oda kodu + güvenlik anahtarını yaz.
4. `Ekranı İzle` seç.

## Güvenlik notları

- Güvenlik anahtarını tahmin edilmesi zor, uzun bir değer yap.
- İnternet üzerinden kullanımda `ws://` yerine mutlaka `wss://` kullan.
- Relay sunucusu ekran görüntüsünü diske kaydetmez; sadece bağlı izleyiciye iletir.
- İstersen bir sonraki sürümde uçtan uca şifreleme eklenebilir.

## Performans

İlk prototip yaklaşık 4 FPS, 720 px genişlik ve JPEG %45 kalite kullanır.
Amaç önce güvenilir bağlantıyı doğrulamaktır. Sonraki aşamada H.264/WebRTC ile akıcılık ve bant genişliği iyileştirilebilir.

## iOS 27 notu

Apple, iOS 27+ için ScreenCaptureKit ile iOS tam ekran yakalama örneği sunuyor.
Bu proje iOS 26 cihazlarda çalışabilmek için ReplayKit Broadcast Upload yaklaşımını kullanır.
