# Ev Ekranı — Mac Olmadan Kurulum

Bu paket iPhone'dan yönetilebilecek bir bulut kurulum akışına hazırlanmıştır.

## Gereken hesaplar

- Apple Developer Program üyeliği
- GitHub hesabı
- Codemagic hesabı
- Relay sunucusu için Render hesabı (veya eşdeğer bir Node/WebSocket hostu)

## A. GitHub'a yükle

1. GitHub'da yeni bir **private** repository oluştur: `evekran`.
2. Bu ZIP'in içindeki dosyaları repository'nin köküne yükle.
3. `codemagic.yaml` dosyasının repository'nin ana dizininde olduğundan emin ol.

## B. Apple tarafını hazırla

Apple Developer web portalında aşağıdakileri oluştur:

1. Bir App Group:
   `group.com.SANA_OZEL.evekran`

2. Ana App Identifier:
   `com.SANA_OZEL.evekran`
   - App Groups capability açık
   - Yukarıdaki App Group bağlı

3. Broadcast Extension Identifier:
   `com.SANA_OZEL.evekran.Broadcast`
   - App Groups capability açık
   - Aynı App Group bağlı

App Store Connect'te yeni uygulama kaydı oluştur:
- Platform: iOS
- İsim: Ev Ekranı
- Bundle ID: ana App Identifier
- SKU: evekran-001

## C. App Store Connect API anahtarı

App Store Connect:
`Users and Access > Integrations > App Store Connect API`

Yeni API key:
- İsim: Codemagic
- Rol: App Manager

Şunları kaydet:
- Issuer ID
- Key ID
- `.p8` dosyası

`.p8` dosyası yalnızca bir kez indirilebilir; güvenli sakla.

## D. Codemagic

1. Codemagic'e GitHub ile giriş yap.
2. `evekran` repository'sini ekle.
3. Uygulama ayarlarında Environment variables bölümüne gir.
4. `appstore_credentials` adlı bir grup oluştur.
5. Aşağıdaki üç değeri ekle ve Secret yap:

- `APP_STORE_CONNECT_PRIVATE_KEY` = `.p8` dosyasının TAM metin içeriği
- `APP_STORE_CONNECT_KEY_IDENTIFIER` = Key ID
- `APP_STORE_CONNECT_ISSUER_ID` = Issuer ID

> iPhone'da `.p8` dosyasını Dosyalar uygulamasında açıp metin içeriğini kopyalayamıyorsan,
> Codemagic'in Developer Portal entegrasyon ekranından dosyayı doğrudan yüklemek daha kolay olabilir.

## E. Bundle ID'leri değiştir

GitHub'da `codemagic.yaml` dosyasını aç ve:

`com.REPLACE.evekran`

yerine Apple Developer'da oluşturduğun ana Bundle ID'yi,

`group.com.REPLACE.evekran`

yerine oluşturduğun App Group'u yaz.

Örnek:
- `com.ornek.evekran`
- `group.com.ornek.evekran`

Commit changes de.

## F. İlk bulut build

Codemagic:
- App > Start new build
- Workflow: `Ev Ekranı - TestFlight`
- Branch: `main`
- Start build

Akış:
1. XcodeGen'i bulut Mac'e kurar.
2. Xcode projesini üretir.
3. Apple dağıtım sertifikası/provisioning profillerini getirir/oluşturur.
4. Ana uygulamayı ve Broadcast Extension'ı imzalar.
5. IPA üretir.
6. App Store Connect'e yükler.

## G. TestFlight

App Store Connect > Ev Ekranı > TestFlight

Build "Processing" bittikten sonra:
- Internal Testing grubuna kendi Apple hesabını ekle.
- İki iPhone'da da TestFlight uygulamasını aç.
- Aynı Apple hesabıyla Ev Ekranı beta sürümünü kur.

Bu `codemagic.yaml`, build'i `TestFlight Internal Testing Only` olarak işaretler.
Bu nedenle amaç kendi cihazlarında test etmektir; dış kullanıcı dağıtımı değildir.

## H. Relay sunucusunu Render'a kur

Repository içinde `render.yaml` hazır.

Render:
1. GitHub hesabını bağla.
2. New > Blueprint veya Web Service.
3. `evekran` repository'sini seç.
4. `render.yaml` algılanırsa Blueprint'i oluştur.

Elle kurarsan:
- Runtime: Node
- Root Directory: `RelayServer`
- Build Command: `npm install`
- Start Command: `npm start`
- Health Check: `/health`

Render sana örneğin:
`https://evekran-relay.onrender.com`

gibi bir adres verir.

Uygulamada WebSocket adresi:
`wss://evekran-relay.onrender.com/ws`

kullan.

## I. İki telefonda ayarlar

EVDEKİ TELEFON:
- Bu telefon evde kalacak
- Sunucu = Render `wss://.../ws`
- Oda kodu = örn. `EV-001`
- Güvenlik anahtarı = uzun rastgele parola
- Yayın düğmesine bas
- `Ev Ekranı Yayını` seç
- Yayını başlat

KONTROL TELEFONU:
- Bu telefon kontrol telefonu
- Aynı sunucu
- Aynı oda kodu
- Aynı güvenlik anahtarı
- `Ekranı İzle`

## iOS sınırı

Ekran yayınını ev telefonunda bir kullanıcı ilk kez başlatmak zorundadır.
iOS'un bu sistem onayını gizlice veya uzaktan atlatmaya yönelik kod yoktur.

## Ses/kamera

- Kamera API'si kullanılmaz.
- Broadcast Picker mikrofon düğmesini göstermez.
- ReplayKit'ten gelen `audioApp` ve `audioMic` paketleri özellikle yok sayılır.
- Relay sunucusu aldığı ekran karelerini diske yazmaz; bağlı izleyiciye iletir.

## İlk build hata verirse

En sık nedenler:
1. App Group Apple Developer portalında oluşturulmamıştır.
2. Ana App ID veya Broadcast App ID'de App Groups capability açık değildir.
3. `codemagic.yaml` içindeki Bundle ID'ler portal ile birebir aynı değildir.
4. API key rolü App Manager değildir.
5. App Store Connect'te ana uygulama kaydı henüz oluşturulmamıştır.

Build logunu ChatGPT'ye gönderirsen hata satırına göre proje ayarını düzeltmek mümkündür.
